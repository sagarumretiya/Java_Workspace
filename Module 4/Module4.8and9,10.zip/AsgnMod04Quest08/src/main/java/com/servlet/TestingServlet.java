package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Pattern;
import com.mysql.jdbc.Driver;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TestingServlet extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//super.doPost(req, resp);
		
		String fname = req.getParameter("fname");
		String lname = req.getParameter("lname");
		String email = req.getParameter("email");
		String mobile = req.getParameter("mobile");		
		String pasword = req.getParameter("password");
		
		resp.setContentType("text/html");
		PrintWriter out = resp.getWriter();
		
		int flag = 0;
		
		if(!checkalphabetic(fname))
		{
			out.println("Enter valid first name <br /> ");
			flag=1;
		}
		if(!checkalphabetic(lname))
		{
			out.println("Enter valid last name <br />");
			flag=1;
		}
		if(!checkEmail(email))
		{
			out.println("Enter valid email<br />");
			flag=1;
		}
		if(!uniqueEmail(email))
		{
			out.println(" email is already in use <br />");
			flag=1;
		}
		
		if(flag ==1)
		{
			out.println("<a href=\"register.jsp\">Register</a>");
		}
	}
	
	private boolean checkalphabetic(String input) {
		if(input.length()==0)
		{
			return false;
		}
		for(int i=0;i!=input.length(); ++i)
		{
			if(!Character.isLetter(input.charAt(i)))
			{
				return false;
			}
		}
		return true;
	}
	
	private boolean checkEmail(String input)
	{
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                "[a-zA-Z0-9_+&*-]+)*@" + 
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                "A-Z]{2,7}$"; 
                  
		Pattern pat = Pattern.compile(emailRegex); 
		if (input == null)
		{
			return false; 			
		}
		
		return pat.matcher(input).matches();
		

	}
	
	private boolean uniqueEmail(String input)
	{
		  
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/asgnmod04quest08","root","");
			
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("select * from user where email = '"+input+"';");
			
			if(!rs.next())
			{
				return true;
			}
			else
			{
				//System.out.println(rs.getInt(1));
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}


	

}
